
import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const initialBikes = [
  {
    id: 1,
    model: "Royal Enfield Bullet 350",
    year: 1998,
    price: "INR 65,000",
    image: "/images/bullet350.jpg",
  },
  {
    id: 2,
    model: "Royal Enfield Classic 500",
    year: 2006,
    price: "INR 85,000",
    image: "/images/classic500.jpg",
  },
];

export default function UsedBikes() {
  const [bikes, setBikes] = useState(initialBikes);
  const [formData, setFormData] = useState({
    model: "",
    year: "",
    price: "",
    image: "",
    contact: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newBike = {
      id: bikes.length + 1,
      model: formData.model,
      year: parseInt(formData.year),
      price: formData.price,
      image: formData.image || "/images/default.jpg",
      contact: formData.contact,
    };
    setBikes([...bikes, newBike]);
    setFormData({ model: "", year: "", price: "", image: "", contact: "" });
  };

  const handleBuyNow = (bike) => {
    const message = `Hello, I am interested in buying the ${bike.model} (${bike.year}) listed for ${bike.price}.`;
    const whatsappURL = `https://wa.me/91XXXXXXXXXX?text=${encodeURIComponent(message)}`;
    window.open(whatsappURL, "_blank");
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="text-4xl font-bold mb-6 text-center text-blue-900">Vintage Royal Enfield Bikes</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {bikes.map((bike) => (
          <Card key={bike.id} className="shadow-xl border border-gray-200">
            <img
              src={bike.image}
              alt={bike.model}
              className="rounded-t-xl h-60 w-full object-cover"
            />
            <CardContent className="space-y-2">
              <h2 className="text-xl font-semibold text-gray-800">{bike.model}</h2>
              <p className="text-sm text-gray-600">Year: {bike.year}</p>
              <p className="font-bold text-green-700">Price: {bike.price}</p>
              <Button className="w-full" onClick={() => handleBuyNow(bike)}>Buy Now</Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-10 border-t pt-6">
        <h2 className="text-2xl font-bold mb-4 text-blue-800">Sell Your Royal Enfield</h2>
        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            name="model"
            placeholder="Bike Model"
            value={formData.model}
            onChange={handleChange}
          />
          <Input
            name="year"
            placeholder="Year of Manufacture"
            type="number"
            value={formData.year}
            onChange={handleChange}
          />
          <Input
            name="price"
            placeholder="Price (INR)"
            type="text"
            value={formData.price}
            onChange={handleChange}
          />
          <Input
            name="image"
            placeholder="Image URL (optional)"
            value={formData.image}
            onChange={handleChange}
          />
          <Input
            name="contact"
            placeholder="Contact Number"
            value={formData.contact}
            onChange={handleChange}
          />
          <Button type="submit" className="md:col-span-2">
            Submit Listing
          </Button>
        </form>
      </div>
    </div>
  );
}
